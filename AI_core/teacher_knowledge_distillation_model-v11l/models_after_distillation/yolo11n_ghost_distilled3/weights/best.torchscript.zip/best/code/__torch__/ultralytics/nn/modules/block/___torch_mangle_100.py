class C3k(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_78.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_81.Conv
  cv3 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_84.Conv
  m : __torch__.torch.nn.modules.container.___torch_mangle_99.Sequential
  def forward(self: __torch__.ultralytics.nn.modules.block.___torch_mangle_100.C3k,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    input: Tensor) -> Tensor:
    cv3 = self.cv3
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _0 = (m).forward(argument_1, (cv1).forward(argument_1, input, ), )
    _1 = [_0, (cv2).forward(argument_1, input, )]
    input0 = torch.cat(_1, 1)
    return (cv3).forward(argument_1, input0, )
